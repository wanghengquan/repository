import xlsx2csv
__author__ = 'syan'
my_args = ["-a", r"D:\zolo\JiangJunLing\aodili\xlib\suite_info3.xlsx", "test"]
print my_args
pp = xlsx2csv.main(my_args)
